/*
 * Copyright (c) 2015 Quantenna Communications, Inc.
 * All rights reserved.
 */
#ifndef __QCSAPI_QFTC_H__
#define __QCSAPI_QFTC_H__
extern int qftc_start(const char *file_path_name, const char *sif_name, const uint8_t *dmac_addr);
#endif
